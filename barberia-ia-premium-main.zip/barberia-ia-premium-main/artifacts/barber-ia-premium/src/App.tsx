import { useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { Bell, CalendarDays, Check, ChevronRight, CircleDollarSign, Download, Edit3, House, Inbox, MessageCircle, MoreHorizontal, Phone, Plus, Scissors, Search, Settings2, Trash2, TrendingUp, Upload, Users, Wallet, X } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

type Profile = { barberName: string; ownerName: string; dailyGoal: number; whatsapp: string; logoDataUrl: string };
type Client = { id: string; name: string; phone: string; lastVisit: string; visits: number };
type AppointmentStatus = 'Confirmado' | 'Pendiente' | 'Cancelado';
type Appointment = { id: string; clientName: string; phone?: string; date: string; time: string; service: string; price: number; status: AppointmentStatus; notes: string };
type Service = { id: string; name: string; price: number };
type Message = { id: string; name: string; preview: string; time: string; phone: string; unread?: boolean };
type InstallEvent = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };

const PROFILE_KEY = 'barberia-profile';
const CLIENTS_KEY = 'barberia-clients';
const APPOINTMENTS_KEY = 'barberia-appointments';
const SERVICES_KEY = 'barberia-services';
const DEFAULT_SERVICES: Service[] = [
  { id: 'degrade', name: 'Degradé', price: 12000 },
  { id: 'degradez', name: 'Degradez', price: 14000 },
  { id: 'clasico', name: 'Clásico', price: 10000 },
  { id: 'barba', name: 'Barba', price: 8000 },
  { id: 'degrade-barba', name: 'Degradé + Barba', price: 18000 },
];
const DEFAULT_PROFILE: Profile = { barberName: 'Corte & Filo', ownerName: 'Lucas Benítez', dailyGoal: 85000, whatsapp: '+54 9 11 4580 2201', logoDataUrl: '' };
const today = () => new Date().toISOString().slice(0, 10);
const uid = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
const money = (value: number) => `$${Math.round(Number(value) || 0).toLocaleString('es-AR')}`;
const dateLabel = (value: string) => new Date(`${value}T12:00:00`).toLocaleDateString('es-AR', { day: 'numeric', month: 'short' }).replace('.', '');
const fullDateLabel = (value: string) => new Date(`${value}T12:00:00`).toLocaleDateString('es-AR', { weekday: 'long', day: 'numeric', month: 'long' });
const initials = (name: string) => name.split(' ').filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || 'B';
const read = <T,>(key: string, fallback: T): T => {
  try {
    const saved = window.localStorage.getItem(key);
    return saved ? JSON.parse(saved) as T : fallback;
  } catch {
    return fallback;
  }
};
const write = (key: string, value: unknown) => window.localStorage.setItem(key, JSON.stringify(value));
const normaliseServiceName = (name: string) => name.replace(/desvanecido/gi, 'Degradé');
const normaliseServices = (stored: Service[] | null): Service[] => {
  if (!stored?.length) return DEFAULT_SERVICES;
  return stored.map((service, index) => ({ id: service.id || `service-${index}`, name: normaliseServiceName(service.name), price: Number(service.price) || DEFAULT_SERVICES[index]?.price || 0 }));
};
const seedClients: Client[] = [
  { id: 'client-mateo', name: 'Mateo Roldán', phone: '+54 9 11 5532 1884', lastVisit: today(), visits: 12 },
  { id: 'client-tomas', name: 'Tomás Aguirre', phone: '+54 9 11 4980 7412', lastVisit: today(), visits: 8 },
  { id: 'client-nicolas', name: 'Nicolás Ferreyra', phone: '+54 9 11 6122 3090', lastVisit: '2025-05-28', visits: 5 },
  { id: 'client-julian', name: 'Julián Sosa', phone: '+54 9 11 4471 9920', lastVisit: '2025-05-25', visits: 16 },
];
const seedAppointments: Appointment[] = [
  { id: 'appointment-1', clientName: 'Mateo Roldán', phone: '+54 9 11 5532 1884', date: today(), time: '09:30', service: 'Degradé', price: 12000, status: 'Confirmado', notes: '' },
  { id: 'appointment-2', clientName: 'Tomás Aguirre', phone: '+54 9 11 4980 7412', date: today(), time: '11:00', service: 'Degradé + Barba', price: 18000, status: 'Confirmado', notes: 'Prefiere máquina al 1.' },
  { id: 'appointment-3', clientName: 'Nicolás Ferreyra', phone: '+54 9 11 6122 3090', date: today(), time: '13:30', service: 'Clásico', price: 10000, status: 'Pendiente', notes: '' },
  { id: 'appointment-4', clientName: 'Julián Sosa', phone: '+54 9 11 4471 9920', date: today(), time: '16:00', service: 'Barba', price: 8000, status: 'Pendiente', notes: '' },
];
const seedMessages: Message[] = [
  { id: 'message-1', name: 'Mateo Roldán', preview: '¿Podemos pasar el turno para las 10?', time: '09:12', phone: '+5491155321884', unread: true },
  { id: 'message-2', name: 'Tomás Aguirre', preview: 'Perfecto, nos vemos a las 11.', time: 'Ayer', phone: '+5491149807412' },
  { id: 'message-3', name: 'Nicolás Ferreyra', preview: 'Hola, ¿tenés lugar esta semana?', time: 'Lun', phone: '+5491161223090' },
];

function useBarberData() {
  const [profile, setProfile] = useState<Profile>(() => ({ ...DEFAULT_PROFILE, ...read<Partial<Profile>>(PROFILE_KEY, {}) }));
  const [clients, setClients] = useState<Client[]>(() => read<Client[]>(CLIENTS_KEY, seedClients));
  const [appointments, setAppointments] = useState<Appointment[]>(() => read<Appointment[]>(APPOINTMENTS_KEY, seedAppointments).map((item) => ({ ...item, service: normaliseServiceName(item.service) })));
  const [services, setServices] = useState<Service[]>(() => normaliseServices(read<Service[] | null>(SERVICES_KEY, null)));
  const [toast, setToast] = useState('');

  useEffect(() => write(PROFILE_KEY, profile), [profile]);
  useEffect(() => write(CLIENTS_KEY, clients), [clients]);
  useEffect(() => write(APPOINTMENTS_KEY, appointments), [appointments]);
  useEffect(() => write(SERVICES_KEY, services), [services]);
  useEffect(() => {
    const link = document.querySelector<HTMLLinkElement>('link[rel="manifest"]') || document.createElement('link');
    const iconType = profile.logoDataUrl.match(/^data:(image\/[^;]+);/)?.[1] || 'image/png';
    const iconSource = profile.logoDataUrl || '/logo-192.png';
    const largeIconSource = profile.logoDataUrl || '/logo-512.png';
    const manifest = {
      name: 'Barbería IA Premium',
      short_name: 'Barbería IA',
      start_url: '/',
      scope: '/',
      id: '/',
      display: 'standalone',
      background_color: '#000000',
      theme_color: '#D4AF37',
      description: 'Agenda y gestión diaria para barberías argentinas.',
      icons: [
        { src: iconSource, sizes: '192x192', type: profile.logoDataUrl ? iconType : 'image/png', purpose: 'any' },
        { src: largeIconSource, sizes: '512x512', type: profile.logoDataUrl ? iconType : 'image/png', purpose: 'any maskable' },
      ],
    };
    link.rel = 'manifest';
    link.href = `data:application/manifest+json,${encodeURIComponent(JSON.stringify(manifest))}`;
    if (!link.parentNode) document.head.appendChild(link);
    document.title = `${profile.barberName} · Gestión`;
    const favicon = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (favicon) favicon.href = profile.logoDataUrl || '/logo-192.png';
    const appleIcon = document.querySelector<HTMLLinkElement>('link[rel="apple-touch-icon"]');
    if (appleIcon) appleIcon.href = profile.logoDataUrl || '/apple-touch-icon.png';
  }, [profile]);
  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 3200);
  };
  const upsertClient = (name: string, phone = '', countVisit = true) => {
    const cleanName = name.trim();
    if (!cleanName) return;
    const found = clients.find((client) => client.name.toLowerCase() === cleanName.toLowerCase());
    if (found) {
      setClients((current) => current.map((client) => client.id === found.id ? {
        ...client,
        phone: phone || client.phone,
        lastVisit: countVisit ? today() : client.lastVisit,
        visits: countVisit ? client.visits + 1 : client.visits,
      } : client));
      return;
    }
    setClients((current) => [...current, { id: uid('client'), name: cleanName, phone, lastVisit: today(), visits: 1 }]);
  };
  const saveAppointment = (item: Appointment, editingId?: string) => {
    setAppointments((current) => editingId ? current.map((appointment) => appointment.id === editingId ? item : appointment) : [...current, item]);
    upsertClient(item.clientName, item.phone, !editingId);
    notify(editingId ? 'Turno actualizado.' : 'Turno guardado y cliente registrado.');
  };
  const deleteAppointment = (id: string) => {
    setAppointments((current) => current.filter((appointment) => appointment.id !== id));
    notify('Turno eliminado.');
  };
  return { profile, setProfile, clients, appointments, services, setServices, saveAppointment, deleteAppointment, toast, notify };
}

const navItems = [
  { href: '/', label: 'Resumen', icon: House },
  { href: '/appointments', label: 'Turnos', icon: CalendarDays },
  { href: '/messages', label: 'Mensajes', icon: Inbox },
  { href: '/settings', label: 'Configuración', icon: Settings2 },
];

function Brand({ profile, mobile = false }: { profile: Profile; mobile?: boolean }) {
  return <div className={mobile ? 'mobile-brand' : 'brand-lockup'}>
    {profile.logoDataUrl ? <img className="brand-mark" src={profile.logoDataUrl} alt="" /> : <div className="brand-mark">C</div>}
    <div><div className="brand-name">{profile.barberName}</div><div className="brand-tag">Gestión premium</div></div>
  </div>;
}

function Shell({ profile, children }: { profile: Profile; children: ReactNode }) {
  const [location] = useLocation();
  const [installEvent, setInstallEvent] = useState<InstallEvent | null>(null);
  useEffect(() => {
    const handler = (event: Event) => { event.preventDefault(); setInstallEvent(event as InstallEvent); };
    window.addEventListener('beforeinstallprompt', handler);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => undefined);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);
  const install = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    setInstallEvent(null);
  };
  return <div className="app-shell">
    <aside className="sidebar">
      <Brand profile={profile} />
      <div className="nav-label">Espacio de trabajo</div>
      <nav className="side-nav" aria-label="Navegación principal">{navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-item ${location === href ? 'active' : ''}`} data-testid={`link-nav-${label.toLowerCase()}`}><Icon className="nav-icon" /><span>{label}</span></Link>)}</nav>
      <div className="sidebar-bottom">
        {installEvent && <button className="tip-card" onClick={install} data-testid="button-install-sidebar"><strong>Instalá la app</strong><p>Tené tu agenda a mano, incluso desde el escritorio.</p></button>}
        <div className="side-footer"><div className="avatar">{initials(profile.ownerName)}</div><span>{profile.ownerName}</span><MoreHorizontal size={15} style={{ marginLeft: 'auto' }} /></div>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar">
        <Brand profile={profile} mobile />
        <div className="header-brand">
          {profile.logoDataUrl ? <img className="header-logo" src={profile.logoDataUrl} alt={`Logo de ${profile.barberName}`} data-testid="img-header-logo" /> : <div className="header-logo header-logo-fallback" data-testid="img-header-logo">C</div>}
          <div className="greeting" data-testid="text-header-barber-name">{profile.barberName}<strong>Buenas, {profile.ownerName.split(' ')[0]}.</strong></div>
        </div>
        <div className="top-actions"><div className="icon-button" title="Notificaciones"><Bell size={16} /></div>{installEvent && <button className="icon-button" title="Instalar aplicación" onClick={install} data-testid="button-install-header"><Download size={16} /></button>}<div className="avatar">{initials(profile.ownerName)}</div></div>
      </header>
      {children}
    </main>
    <nav className="mobile-nav" aria-label="Navegación móvil">{navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-item ${location === href ? 'active' : ''}`} data-testid={`link-mobile-nav-${label.toLowerCase()}`}><Icon className="nav-icon" /><span>{label}</span></Link>)}</nav>
  </div>;
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1>{description && <p className="subheading">{description}</p>}</div>{action}</div>;
}

function Dashboard({ profile, appointments }: { profile: Profile; appointments: Appointment[] }) {
  const todays = appointments.filter((item) => item.date === today() && item.status !== 'Cancelado').sort((a, b) => a.time.localeCompare(b.time));
  const revenue = todays.reduce((sum, item) => sum + item.price, 0);
  const confirmed = todays.filter((item) => item.status === 'Confirmado').length;
  return <div className="content">
    <PageHeading eyebrow={fullDateLabel(today())} title="Tu día, en orden." description="Una mirada rápida a lo que pasa hoy." action={<Link href="/appointments?new=1" className="primary-button" data-testid="button-new-appointment"><Plus className="button-icon" />Nuevo turno</Link>} />
    <div className="metrics-grid">
      <div className="metric-card"><div className="metric-top"><span>Ingresos de hoy</span><div className="metric-icon"><CircleDollarSign size={15} /></div></div><div className="metric-value" data-testid="text-today-revenue">{money(revenue)}</div><div className="metric-trend"><TrendingUp size={11} style={{ verticalAlign: 'middle' }} /> Agenda confirmada</div></div>
      <div className="metric-card"><div className="metric-top"><span>Turnos del día</span><div className="metric-icon"><CalendarDays size={15} /></div></div><div className="metric-value" data-testid="text-today-appointments">{todays.length}</div><div className="metric-trend neutral">{confirmed} confirmados</div></div>
      <div className="metric-card"><div className="metric-top"><span>Clientes activos</span><div className="metric-icon"><Users size={15} /></div></div><div className="metric-value" data-testid="text-active-clients">{appointments.length ? new Set(appointments.map((item) => item.clientName.toLowerCase())).size : 0}</div><div className="metric-trend neutral">En tu historial</div></div>
      <div className="metric-card"><div className="metric-top"><span>Ticket promedio</span><div className="metric-icon"><Wallet size={15} /></div></div><div className="metric-value" data-testid="text-average-ticket">{money(todays.length ? revenue / todays.length : 0)}</div><div className="metric-trend neutral">Por turno</div></div>
    </div>
    <div className="dashboard-grid">
      <section className="panel"><div className="panel-heading"><div><h2>Agenda de hoy</h2><p>{todays.length ? `${todays.length} turnos programados` : 'Todavía no hay turnos'}</p></div><Link href="/appointments" className="panel-link" data-testid="link-see-all-appointments">Ver agenda</Link></div><div className="schedule-list">{todays.length ? todays.map((item) => <div className="appointment-row" key={item.id} data-testid={`row-dashboard-appointment-${item.id}`}><div className="appointment-time">{item.time}</div><div><div className="appointment-client">{item.clientName}</div><div className="appointment-service">{item.service} · <span className={`status status-${item.status.toLowerCase()}`}>{item.status}</span></div></div><div className="appointment-price">{money(item.price)}</div></div>) : <div className="empty-state">Tu agenda está libre. Sumá el primer turno del día.</div>}</div></section>
      <div><section className="panel goal-panel"><div className="goal-title"><div><h2>Objetivo diario</h2><p className="subheading">Tu meta de facturación</p></div><span>{Math.min(100, Math.round((revenue / (profile.dailyGoal || 1)) * 100))}%</span></div><div className="goal-amount">{money(revenue)} <small>/ {money(profile.dailyGoal)}</small></div><div className="progress-track"><div className="progress-fill" style={{ width: `${Math.min(100, (revenue / (profile.dailyGoal || 1)) * 100)}%` }} /></div><div className="goal-meta"><span>Facturado</span><span>Faltan {money(Math.max(0, profile.dailyGoal - revenue))}</span></div></section><section className="insight-card"><p className="eyebrow">Dato de tu negocio</p><h2>La constancia llena la agenda.</h2><p>Confirmá tus turnos con tiempo y dejá que tus clientes sepan que tienen su lugar guardado.</p></section></div>
    </div>
  </div>;
}

function AppointmentForm({ editing, services, clients, onClose, onSave }: { editing?: Appointment; services: Service[]; clients: Client[]; onClose: () => void; onSave: (appointment: Appointment, editingId?: string) => void }) {
  const [form, setForm] = useState<Appointment>(() => editing || { id: uid('appointment'), clientName: '', phone: '', date: today(), time: '10:00', service: services[0]?.name || 'Degradé', price: services[0]?.price || 12000, status: 'Pendiente', notes: '' });
  const [showSuggestions, setShowSuggestions] = useState(false);
  const filteredClients = clients.filter((client) => form.clientName && client.name.toLowerCase().includes(form.clientName.toLowerCase())).slice(0, 5);
  const update = (key: keyof Appointment, value: string | number) => setForm((current) => ({ ...current, [key]: value }));
  const chooseService = (name: string) => update('price', services.find((service) => service.name === name)?.price || form.price);
  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!form.clientName.trim() || !form.date || !form.time) return;
    onSave({ ...form, clientName: form.clientName.trim(), price: Number(form.price) || 0 }, editing?.id);
    onClose();
  };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><div className="modal" role="dialog" aria-modal="true" aria-labelledby="appointment-modal-title">
    <div className="modal-header"><div><p className="eyebrow">{editing ? 'Editar agenda' : 'Nueva reserva'}</p><h2 id="appointment-modal-title">{editing ? 'Actualizar turno' : 'Nuevo turno'}</h2></div><button className="close-button" onClick={onClose} aria-label="Cerrar" data-testid="button-close-appointment"><X size={16} /></button></div>
    <form onSubmit={submit}><div className="form-grid">
      <div className="field full"><label htmlFor="client-name">Nombre del cliente</label><div className="autocomplete"><input id="client-name" className="input" autoFocus value={form.clientName} placeholder="Escribí un nombre" onFocus={() => setShowSuggestions(true)} onChange={(event) => { update('clientName', event.target.value); setShowSuggestions(true); }} data-testid="input-appointment-client" />{showSuggestions && filteredClients.length > 0 && <div className="suggestions">{filteredClients.map((client) => <button type="button" className="suggestion" key={client.id} onClick={() => { setForm((current) => ({ ...current, clientName: client.name, phone: client.phone })); setShowSuggestions(false); }} data-testid={`button-suggest-client-${client.id}`}><span>{client.name}</span><small>{client.phone || 'Sin teléfono'}</small></button>)}</div>}</div><span className="field-hint">Si es nuevo, lo guardamos en tu historial al confirmar.</span></div>
      <div className="field"><label htmlFor="client-phone">Teléfono <span className="field-hint">(opcional)</span></label><input id="client-phone" className="input" value={form.phone || ''} placeholder="+54 9 11..." onChange={(event) => update('phone', event.target.value)} data-testid="input-appointment-phone" /></div>
      <div className="field"><label htmlFor="appointment-date">Fecha</label><input id="appointment-date" type="date" className="input" value={form.date} onChange={(event) => update('date', event.target.value)} data-testid="input-appointment-date" /></div>
      <div className="field"><label htmlFor="appointment-time">Hora</label><input id="appointment-time" type="time" className="input" value={form.time} onChange={(event) => update('time', event.target.value)} data-testid="input-appointment-time" /></div>
      <div className="field"><label htmlFor="appointment-service">Servicio</label><select id="appointment-service" className="select" value={form.service} onChange={(event) => { update('service', event.target.value); chooseService(event.target.value); }} data-testid="select-appointment-service">{services.map((service) => <option value={service.name} key={service.id}>{service.name}</option>)}</select></div>
      <div className="field"><label htmlFor="appointment-price">Precio</label><input id="appointment-price" type="number" className="input" value={form.price} onChange={(event) => update('price', Number(event.target.value))} data-testid="input-appointment-price" /></div>
      <div className="field"><label htmlFor="appointment-status">Estado</label><select id="appointment-status" className="select" value={form.status} onChange={(event) => update('status', event.target.value as AppointmentStatus)} data-testid="select-appointment-status"><option>Confirmado</option><option>Pendiente</option><option>Cancelado</option></select></div>
      <div className="field full"><label htmlFor="appointment-notes">Notas <span className="field-hint">(opcional)</span></label><textarea id="appointment-notes" className="textarea" value={form.notes} placeholder="Un detalle para recordar..." onChange={(event) => update('notes', event.target.value)} data-testid="textarea-appointment-notes" /></div>
    </div><div className="form-actions"><button type="button" className="secondary-button" onClick={onClose} data-testid="button-cancel-appointment">Cancelar</button><button type="submit" className="primary-button" data-testid="button-save-appointment"><Check className="button-icon" />{editing ? 'Guardar cambios' : 'Confirmar turno'}</button></div></form>
  </div></div>;
}

function AppointmentsPage({ data }: { data: ReturnType<typeof useBarberData> }) {
  const [modal, setModal] = useState<'new' | Appointment | null>(null);
  const [query, setQuery] = useState('');
  const [location] = useLocation();
  useEffect(() => {
    if (location.includes('?new=1')) setModal('new');
  }, [location]);
  const filtered = data.appointments.filter((item) => `${item.clientName} ${item.service}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  return <div className="content"><PageHeading eyebrow="Agenda" title="Turnos" description="Organizá tu día y no dejes ningún hueco sin aprovechar." action={<button className="primary-button" onClick={() => setModal('new')} data-testid="button-new-appointment-page"><Plus className="button-icon" />Nuevo turno</button>} />
    <div className="filter-bar"><div className="search-field"><Search size={15} /><input className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar por cliente o servicio" data-testid="input-search-appointments" /></div><button className="secondary-button" onClick={() => setQuery('')} data-testid="button-clear-appointment-search">Limpiar</button></div>
    <section className="panel table-wrap"><table className="data-table"><thead><tr><th>Cliente</th><th>Fecha y hora</th><th>Servicio</th><th>Estado</th><th>Importe</th><th aria-label="Acciones" /></tr></thead><tbody>{filtered.map((item) => <tr key={item.id} data-testid={`row-appointment-${item.id}`}><td><div className="table-client">{item.clientName}</div><div className="field-hint">{item.phone || 'Sin teléfono'}</div></td><td>{dateLabel(item.date)} · {item.time}</td><td>{item.service}</td><td><span className={`status status-${item.status.toLowerCase()}`}>{item.status}</span></td><td>{money(item.price)}</td><td><div className="row-actions"><button className="icon-button small-icon" title="Editar turno" onClick={() => setModal(item)} data-testid={`button-edit-appointment-${item.id}`}><Edit3 size={14} /></button><button className="icon-button small-icon" title="Eliminar turno" onClick={() => { if (window.confirm('¿Querés eliminar este turno?')) data.deleteAppointment(item.id); }} data-testid={`button-delete-appointment-${item.id}`}><Trash2 size={14} /></button></div></td></tr>)}</tbody></table>{!filtered.length && <div className="empty-state">No encontramos turnos con esa búsqueda.</div>}</section>
    {modal && <AppointmentForm editing={modal === 'new' ? undefined : modal} services={data.services} clients={data.clients} onClose={() => setModal(null)} onSave={data.saveAppointment} />}
    {data.toast && <div className="toast-note" data-testid="status-toast">{data.toast}</div>}
  </div>;
}

function MessagesPage({ profile }: { profile: Profile }) {
  const [selected, setSelected] = useState(seedMessages[0]);
  const [text, setText] = useState('');
  const [sent, setSent] = useState<string[]>([]);
  const sendMessage = () => { if (!text.trim()) return; setSent((current) => [...current, text.trim()]); setText(''); };
  return <div className="content"><PageHeading eyebrow="Comunicación" title="Mensajes" description="Respondé rápido y mantené el vínculo con tus clientes." action={<button className="secondary-button" onClick={() => window.open(`https://wa.me/${profile.whatsapp.replace(/\D/g, '')}`, '_blank')} data-testid="button-open-whatsapp"><MessageCircle className="button-icon" />Abrir WhatsApp</button>} />
    <div className="message-layout"><section className="panel"><div className="panel-heading"><div><h2>Bandeja</h2><p>{seedMessages.filter((message) => message.unread).length} mensaje sin leer</p></div><button className="icon-button" title="Más opciones" data-testid="button-message-options"><MoreHorizontal size={16} /></button></div><div className="message-list">{seedMessages.map((message) => <button key={message.id} className={`message-item ${selected.id === message.id ? 'selected' : ''}`} onClick={() => setSelected(message)} data-testid={`button-message-${message.id}`}><div className="avatar">{initials(message.name)}</div><div className="message-meta"><div className="message-meta-top"><strong>{message.name}</strong><time>{message.time}</time></div><p className="message-preview">{message.preview}</p></div>{message.unread && <span className="status status-pendiente">Nuevo</span>}</button>)}</div></section>
      <section className="panel conversation"><div className="conversation-head"><div className="avatar">{initials(selected.name)}</div><div><h2>{selected.name}</h2><p className="subheading">{selected.phone}</p></div><button className="icon-button" style={{ marginLeft: 'auto' }} title="Llamar" onClick={() => window.open(`tel:${selected.phone}`, '_self')} data-testid="button-call-client"><Phone size={15} /></button></div><div className="conversation-body"><div className="bubble">{selected.preview}</div>{sent.map((message, index) => <div className="bubble out" key={`${message}-${index}`}>{message}</div>)}</div><div className="conversation-footer"><input className="input" value={text} onChange={(event) => setText(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') sendMessage(); }} placeholder="Escribí un mensaje..." data-testid="input-message-reply" /><button className="primary-button" onClick={sendMessage} data-testid="button-send-message">Enviar</button></div></section>
    </div>
  </div>;
}

function SettingsPage({ data }: { data: ReturnType<typeof useBarberData> }) {
  const [draft, setDraft] = useState(data.profile);
  const [saved, setSaved] = useState('');
  const [serviceDraft, setServiceDraft] = useState(data.services);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => setDraft(data.profile), [data.profile]);
  const save = (event: FormEvent) => { event.preventDefault(); data.setProfile({ ...draft, dailyGoal: Number(draft.dailyGoal) || 0 }); data.setServices(serviceDraft.map((service) => ({ ...service, price: Number(service.price) || 0, name: normaliseServiceName(service.name) }))); setSaved('Cambios guardados.'); window.setTimeout(() => setSaved(''), 2600); };
  const readLogo = (file: File) => { const reader = new FileReader(); reader.onload = () => setDraft((current) => ({ ...current, logoDataUrl: String(reader.result || '') })); reader.readAsDataURL(file); };
  const addService = () => setServiceDraft((current) => [...current, { id: uid('service'), name: 'Nuevo servicio', price: 0 }]);
  return <div className="content"><PageHeading eyebrow="Tu negocio" title="Configuración" description="Dejá tu barbería lista para trabajar a tu manera." /><div className="settings-layout"><form className="panel settings-card" onSubmit={save}><div className="panel-heading" style={{ padding: 0, marginBottom: 20 }}><div><h2>Mi barbería</h2><p>Estos datos aparecen en tu agenda y cuando la instalás.</p></div><Scissors size={19} color="#c9a45f" /></div><div className="logo-upload"><div className="logo-preview">{draft.logoDataUrl ? <img src={draft.logoDataUrl} alt="Vista previa del logo" data-testid="img-logo-preview" /> : initials(draft.barberName).slice(0, 1)}</div><div className="logo-copy"><strong>Subir logo de tu barbería</strong><span>PNG o JPG · Recomendado 512 × 512</span></div><input ref={fileRef} type="file" className="file-input" accept="image/png,image/jpeg,image/webp" aria-label="Subir logo de tu barbería" onChange={(event) => { const file = event.target.files?.[0]; if (file) readLogo(file); }} data-testid="input-barber-logo" /><button type="button" className="secondary-button" onClick={() => fileRef.current?.click()} data-testid="button-upload-logo"><Upload className="button-icon" />{draft.logoDataUrl ? 'Cambiar' : 'Subir logo'}</button>{draft.logoDataUrl && <button type="button" className="icon-button" title="Quitar logo" onClick={() => setDraft((current) => ({ ...current, logoDataUrl: '' }))} data-testid="button-remove-logo"><Trash2 size={15} /></button>}</div>
      <div className="form-grid"><div className="field"><label htmlFor="barber-name">Nombre de la barbería</label><input id="barber-name" className="input" value={draft.barberName} onChange={(event) => setDraft({ ...draft, barberName: event.target.value })} data-testid="input-barber-name" /></div><div className="field"><label htmlFor="owner-name">Nombre del dueño</label><input id="owner-name" className="input" value={draft.ownerName} onChange={(event) => setDraft({ ...draft, ownerName: event.target.value })} data-testid="input-owner-name" /></div><div className="field"><label htmlFor="daily-goal">Objetivo diario</label><input id="daily-goal" type="number" className="input" value={draft.dailyGoal} onChange={(event) => setDraft({ ...draft, dailyGoal: Number(event.target.value) })} data-testid="input-daily-goal" /><span className="field-hint">La meta que aparece en tu resumen.</span></div><div className="field"><label htmlFor="barber-whatsapp">WhatsApp del negocio</label><input id="barber-whatsapp" className="input" value={draft.whatsapp} placeholder="+54 9 11..." onChange={(event) => setDraft({ ...draft, whatsapp: event.target.value })} data-testid="input-barber-whatsapp" /><span className="field-hint">Para abrir conversaciones desde Mensajes.</span></div></div><div className="form-actions"><button type="submit" className="primary-button" data-testid="button-save-profile"><Check className="button-icon" />Guardar configuración</button></div>{saved && <div className="toast-note" style={{ position: 'relative', right: 'auto', bottom: 'auto', marginTop: 14 }} data-testid="status-settings-saved">{saved}</div>}</form>
      <div><section className="panel settings-card"><div className="panel-heading" style={{ padding: 0 }}><div><h2>Servicios y precios</h2><p>Personalizá lo que ofrecés.</p></div><button className="secondary-button" onClick={addService} data-testid="button-add-service"><Plus className="button-icon" />Agregar</button></div><div className="service-list">{serviceDraft.map((service, index) => <div className="service-row" key={service.id}><input className="input service-name" value={service.name} onChange={(event) => setServiceDraft((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, name: event.target.value } : item))} data-testid={`input-service-name-${service.id}`} /><input className="input service-price" type="number" value={service.price} onChange={(event) => setServiceDraft((current) => current.map((item, itemIndex) => itemIndex === index ? { ...item, price: Number(event.target.value) } : item))} data-testid={`input-service-price-${service.id}`} /><button className="icon-button service-remove" type="button" title="Eliminar servicio" onClick={() => setServiceDraft((current) => current.filter((item) => item.id !== service.id))} data-testid={`button-remove-service-${service.id}`}><Trash2 size={14} /></button></div>)}</div></section><section className="panel settings-card"><div className="panel-heading" style={{ padding: 0, marginBottom: 13 }}><div><h2>Accesos rápidos</h2><p>Lo que necesitás tener cerca.</p></div></div><div className="quick-links"><Link className="quick-link" href="/clients" data-testid="link-settings-clients"><span><Users size={15} style={{ verticalAlign: 'middle', marginRight: 9 }} />Historial de clientes</span><ChevronRight size={15} /></Link><Link className="quick-link" href="/appointments" data-testid="link-settings-agenda"><span><CalendarDays size={15} style={{ verticalAlign: 'middle', marginRight: 9 }} />Ver agenda completa</span><ChevronRight size={15} /></Link></div></section></div></div></div>;
}

function ClientsPage({ clients }: { clients: Client[] }) {
  const [query, setQuery] = useState('');
  const filtered = clients.filter((client) => client.name.toLowerCase().includes(query.toLowerCase()));
  return <div className="content"><PageHeading eyebrow="Historial" title="Clientes" description="Toda la historia de quienes vuelven a tu silla." action={<Link className="secondary-button" href="/settings" data-testid="link-back-settings"><Settings2 className="button-icon" />Volver a configuración</Link>} /><div className="filter-bar"><div className="search-field"><Search size={15} /><input className="input" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar cliente" data-testid="input-search-clients" /></div></div><div className="client-list">{filtered.map((client) => <div className="client-card" key={client.id} data-testid={`card-client-${client.id}`}><div className="client-primary"><div className="avatar">{initials(client.name)}</div><div><strong>{client.name}</strong><span>{client.phone || 'Sin teléfono registrado'}</span></div></div><div className="client-stats"><div><strong>{client.visits}</strong>visitas</div><div><strong>{dateLabel(client.lastVisit)}</strong>último turno</div><button className="icon-button small-icon" title="Contactar cliente" onClick={() => window.open(`https://wa.me/${client.phone.replace(/\D/g, '')}`, '_blank')} data-testid={`button-contact-client-${client.id}`}><MessageCircle size={14} /></button></div></div>)}{!filtered.length && <div className="empty-state panel">Todavía no hay clientes con ese nombre.</div>}</div></div>;
}

function Router({ data }: { data: ReturnType<typeof useBarberData> }) {
  return <Switch><Route path="/"><Dashboard profile={data.profile} appointments={data.appointments} /></Route><Route path="/appointments"><AppointmentsPage data={data} /></Route><Route path="/messages"><MessagesPage profile={data.profile} /></Route><Route path="/settings"><SettingsPage data={data} /></Route><Route path="/clients"><ClientsPage clients={data.clients} /></Route><Route><div className="content"><PageHeading eyebrow="404" title="No encontramos esa pantalla." description="Volvé al resumen para seguir con tu agenda." action={<Link href="/" className="primary-button" data-testid="link-back-home"><House className="button-icon" />Ir al resumen</Link>} /></div></Route></Switch>;
}

function App() {
  const data = useBarberData();
  return <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Shell profile={data.profile}><Router data={data} /></Shell></WouterRouter>;
}

export default App;